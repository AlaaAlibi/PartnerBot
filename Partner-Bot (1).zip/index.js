 
const { prefix, channelID, status, activity, errTitle, errNoUser, errNoDesc, roleID } = require('./config.json')
const Discord = require('discord.js');
console.log("[V. D.JS] "+Discord.version)
console.log("[V. NODE] "+process.version)
const client = new Discord.Client({intents: [Discord.Intents.FLAGS.GUILDS, Discord.Intents.FLAGS.GUILD_MESSAGES] })
client.login(process.env.token)
client.on('ready', () => {
client.user.setActivity(activity);
client.user.setStatus(status);
})
client.on('messageCreate', async message => {
  if (message.content.startsWith(`${prefix}partner`)) {
    try {
    const user = message.mentions.users.first();
     let args = message.content.split(" ");
    const role = guild.roles.cache.find((r) => r.id === roleID);
    const PartnerContent = args.slice(0).join(' ');
    const ChannelToSend = await message.client.channels.cache.get(channelID)
    const NoUser = new Discord.MessageEmbed()
    .setTitle(`${errTitle}`)
    .setDescription(`${errNoUser}`)
    if(!user) return message.channel.send({embeds: [NoUser]});
    const NoContent = new Discord.MessageEmbed()
    .setTitle(errTitle)
    .setDescription(errNoDesc)
    if (!PartnerContent) return message.channel.send({embeds: [NoContent]});
    const NotAllowed = new Discord.MessageEmbed()
    .setTitle(`${errTitle}`)
    .setDescription(`${errNotAllowed}`)
    if (!message.member.roles.has(roleID)) return message.channel.send({embeds: [NotAllowed]})
    else 
    message.channel.send({content: `${PartnerContent}`+ "\n========================================\n Fatta con: <@!" + user.id+">\n========================================\n Employee: <@!" + message.author.id + ">"})
  } catch (err) {
    message.channel.send({embeds: [new Discord.MessageEmbed()
    .setTitle(errTitle)
    .setDescription("something went wrong..\nstop code:\n"+err)]})
  }
  }
})